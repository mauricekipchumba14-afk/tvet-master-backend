export default function StatCard({
  label, value, note, accent = 'blueprint',
}: { label: string; value: string; note?: string; accent?: 'blueprint' | 'orange' | 'green' }) {
  const borderColor = {
    blueprint: 'border-t-blueprint',
    orange: 'border-t-signal-orange',
    green: 'border-t-circuit-green',
  }[accent];
  const noteColor = {
    blueprint: 'text-blueprint',
    orange: 'text-signal-orange',
    green: 'text-circuit-green',
  }[accent];

  return (
    <div className={`bg-white rounded-2xl shadow-card p-7 border-t-4 ${borderColor}`}>
      <div className="text-[11px] font-semibold uppercase tracking-wide text-gray-400 mb-2.5">{label}</div>
      <div className="text-3xl font-bold">{value}</div>
      {note && <div className={`text-[13px] font-medium mt-1.5 ${noteColor}`}>{note}</div>}
    </div>
  );
}
