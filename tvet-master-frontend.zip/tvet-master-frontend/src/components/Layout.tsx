import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../lib/auth';

// Responsive app shell: full sidebar on tablet/desktop, bottom tab bar on
// phones. No fixed orientation or fixed pixel widths are used anywhere here,
// so rotating a phone simply reflows the CSS grid/flex layout underneath.
const NAV_ITEMS = [
  { to: '/dashboard', label: 'Dashboard', icon: '🏠' },
  { to: '/units', label: 'My Units', icon: '📚' },
  { to: '/results', label: 'Results', icon: '📊' },
  { to: '/timetable', label: 'Timetable', icon: '🗓️' },
  { to: '/library', label: 'Library', icon: '📖' },
  { to: '/ai-tutor', label: 'AI Tutor', icon: '🤖' },
  { to: '/leaderboard', label: 'Leaderboard', icon: '🏆' },
];

const BOTTOM_ITEMS = NAV_ITEMS.slice(0, 4);

export default function Layout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex">
      {/* Sidebar — hidden below md, generous padding above it */}
      <aside className="hidden md:flex md:flex-col w-64 lg:w-72 bg-blueprint-deep text-white p-9 gap-2 shrink-0">
        <div className="flex items-center gap-3 mb-10 px-1">
          <div className="w-9 h-9 rounded-lg bg-signal-orange flex items-center justify-center font-bold mono">TM</div>
          <span className="font-bold text-base">TVET Master</span>
        </div>
        {NAV_ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm font-medium transition-colors ${
                isActive ? 'bg-white/10 text-white' : 'text-blue-100/70 hover:bg-white/5 hover:text-white'
              }`
            }
          >
            <span>{item.icon}</span>
            {item.label}
          </NavLink>
        ))}
        <button
          onClick={() => { logout(); navigate('/login'); }}
          className="mt-auto flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm font-medium text-blue-100/70 hover:bg-white/5 hover:text-white"
        >
          🚪 Sign out
        </button>
      </aside>

      {/* Main content — max padding as requested, scales down gracefully on small screens */}
      <main className="flex-1 p-6 sm:p-8 md:p-10 lg:p-14 pb-28 md:pb-14 max-w-[1280px] mx-auto w-full">
        {children}
      </main>

      {/* Bottom tab bar — phones only */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white shadow-[0_-4px_20px_rgba(10,55,96,0.1)] flex justify-around px-2 pt-2 pb-[calc(0.5rem+env(safe-area-inset-bottom))] z-40">
        {BOTTOM_ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              `flex flex-col items-center gap-1 text-[10.5px] font-semibold ${
                isActive ? 'text-signal-orange' : 'text-gray-400'
              }`
            }
          >
            <span className="text-lg">{item.icon}</span>
            {item.label}
          </NavLink>
        ))}
      </nav>
    </div>
  );
}
