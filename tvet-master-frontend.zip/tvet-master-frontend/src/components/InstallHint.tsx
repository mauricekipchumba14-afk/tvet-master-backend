import { useEffect, useState } from 'react';

// Captures the browser's install prompt so we can trigger it from our own
// button instead of relying on the OS's default (often hidden) UI.
export default function InstallHint() {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    function handler(e: Event) {
      e.preventDefault();
      setDeferredPrompt(e);
    }
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  if (!deferredPrompt || dismissed) return null;

  return (
    <div className="flex items-center justify-between gap-4 bg-white border-2 border-dashed border-gray-200 rounded-xl px-5 py-4 mb-6 text-sm">
      <span className="text-blueprint-deep">
        ⬇️ Install TVET Master on your home screen for offline access and faster loading.
      </span>
      <div className="flex gap-2 shrink-0">
        <button
          onClick={async () => { deferredPrompt.prompt(); setDeferredPrompt(null); }}
          className="bg-signal-orange text-white text-xs font-semibold px-4 py-2 rounded-lg"
        >
          Install
        </button>
        <button onClick={() => setDismissed(true)} className="text-gray-400 text-xs font-semibold px-2">
          Dismiss
        </button>
      </div>
    </div>
  );
}
