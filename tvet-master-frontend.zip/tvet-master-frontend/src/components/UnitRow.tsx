export default function UnitRow({
  code, name, trainer, score, grade,
}: { code: string; name: string; trainer: string; score?: number; grade?: string }) {
  const passing = (score ?? 0) >= 70;
  return (
    <div className="flex items-center justify-between p-5 rounded-xl bg-mist mb-3 last:mb-0">
      <div>
        <span className="unit-code-tag">{code}</span>
        <div className="font-semibold text-sm mt-2">{name}</div>
        <div className="text-xs text-gray-400 mt-0.5">{trainer}</div>
      </div>
      {score != null && (
        <span className={passing ? 'badge-pass' : 'badge-watch'}>{score} · {grade}</span>
      )}
    </div>
  );
}
