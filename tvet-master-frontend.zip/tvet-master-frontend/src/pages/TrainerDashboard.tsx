import Layout from '../components/Layout';
import StatCard from '../components/StatCard';

export default function TrainerDashboard() {
  return (
    <Layout>
      <h1 className="text-2xl sm:text-[26px] font-bold text-blueprint-deep mb-1">Trainer Dashboard</h1>
      <p className="text-sm text-gray-400 mb-9">Your assigned units and classes</p>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 mb-9">
        <StatCard label="Assigned Units" value="4" accent="blueprint" />
        <StatCard label="Students" value="128" accent="orange" />
        <StatCard label="Pending Grading" value="12" note="Needs attention" accent="green" />
      </div>

      <div className="card">
        <h2 className="font-bold text-blueprint-deep text-[17px] mb-6">Quick actions</h2>
        <div className="grid sm:grid-cols-2 gap-4">
          <button className="text-left p-5 rounded-xl bg-mist hover:bg-blueprint/5 transition-colors">
            <div className="font-semibold text-sm mb-1">📝 Enter marks</div>
            <div className="text-xs text-gray-400">Update CAT / exam scores for your classes</div>
          </button>
          <button className="text-left p-5 rounded-xl bg-mist hover:bg-blueprint/5 transition-colors">
            <div className="font-semibold text-sm mb-1">❓ Add to question bank</div>
            <div className="text-xs text-gray-400">Build up quizzes for your units</div>
          </button>
          <button className="text-left p-5 rounded-xl bg-mist hover:bg-blueprint/5 transition-colors">
            <div className="font-semibold text-sm mb-1">📤 Upload materials</div>
            <div className="text-xs text-gray-400">Notes, past papers, worked examples</div>
          </button>
          <button className="text-left p-5 rounded-xl bg-mist hover:bg-blueprint/5 transition-colors">
            <div className="font-semibold text-sm mb-1">📢 Post announcement</div>
            <div className="text-xs text-gray-400">Notify a class or department</div>
          </button>
        </div>
      </div>
    </Layout>
  );
}
