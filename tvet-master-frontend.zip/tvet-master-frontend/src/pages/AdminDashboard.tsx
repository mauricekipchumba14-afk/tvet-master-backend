import Layout from '../components/Layout';
import StatCard from '../components/StatCard';

export default function AdminDashboard() {
  return (
    <Layout>
      <h1 className="text-2xl sm:text-[26px] font-bold text-blueprint-deep mb-1">Institution Overview</h1>
      <p className="text-sm text-gray-400 mb-9">Rift Valley National Polytechnic</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-9">
        <StatCard label="Departments" value="7" accent="blueprint" />
        <StatCard label="Students" value="2,340" accent="orange" />
        <StatCard label="Trainers" value="86" accent="green" />
        <StatCard label="Pass Rate" value="82%" note="↑ 3% this term" accent="blueprint" />
      </div>

      <div className="card">
        <h2 className="font-bold text-blueprint-deep text-[17px] mb-6">Manage</h2>
        <div className="grid sm:grid-cols-3 gap-4">
          {['Departments', 'Courses & Units', 'Users', 'Intakes & Classes', 'Subscription', 'Announcements'].map((item) => (
            <button key={item} className="text-left p-5 rounded-xl bg-mist hover:bg-blueprint/5 transition-colors font-semibold text-sm">
              {item} →
            </button>
          ))}
        </div>
      </div>
    </Layout>
  );
}
