import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../lib/api';
import { useAuth } from '../lib/auth';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const login = useAuth((s) => s.login);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const { data } = await api.post('/auth/login', { email, password });
      login(data.user, data.accessToken);
      navigate('/dashboard');
    } catch {
      setError('Invalid email or password. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div
      className="min-h-screen flex items-center justify-center p-6"
      style={{
        background:
          'linear-gradient(#0A3760,#0A3760), repeating-linear-gradient(0deg, rgba(255,255,255,0.05) 0 1px, transparent 1px 40px), repeating-linear-gradient(90deg, rgba(255,255,255,0.05) 0 1px, transparent 1px 40px)',
      }}
    >
      <form
        onSubmit={handleSubmit}
        className="bg-white w-full max-w-md rounded-2xl p-10 sm:p-14 shadow-lift relative"
      >
        <span className="absolute -top-3.5 left-10 bg-signal-orange text-white text-[11px] font-semibold mono px-3 py-1.5 rounded-md -rotate-2 shadow">
          TVET MASTER
        </span>
        <h1 className="text-2xl font-bold text-blueprint-deep mt-2 mb-1">Welcome back</h1>
        <p className="text-sm text-gray-400 mb-9">Sign in to your institution's learning portal</p>

        <label className="block text-xs font-semibold uppercase tracking-wide text-blueprint-deep mb-1.5">
          Email
        </label>
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@institution.ac.ke"
          className="w-full px-4 py-3.5 mb-5 border-2 border-gray-200 rounded-xl bg-mist focus:bg-white focus:border-blueprint outline-none text-[15px]"
        />

        <label className="block text-xs font-semibold uppercase tracking-wide text-blueprint-deep mb-1.5">
          Password
        </label>
        <input
          type="password"
          required
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="••••••••"
          className="w-full px-4 py-3.5 mb-6 border-2 border-gray-200 rounded-xl bg-mist focus:bg-white focus:border-blueprint outline-none text-[15px]"
        />

        {error && <p className="text-sm text-red-600 mb-4">{error}</p>}

        <button type="submit" disabled={loading} className="btn-primary disabled:opacity-60">
          {loading ? 'Signing in…' : 'Sign in'}
        </button>

        <p className="text-center text-[13px] text-gray-400 mt-6">
          New student? Ask your registrar for enrollment details.
        </p>
      </form>
    </div>
  );
}
