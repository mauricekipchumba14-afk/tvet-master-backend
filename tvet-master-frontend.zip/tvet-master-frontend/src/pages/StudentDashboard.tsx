import { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import StatCard from '../components/StatCard';
import UnitRow from '../components/UnitRow';
import { useAuth } from '../lib/auth';
import api from '../lib/api';
import InstallHint from '../components/InstallHint';

interface ResultRow {
  score: number;
  assessment: { title: string; unit: { unitCode: string; unitName: string } };
}

export default function StudentDashboard() {
  const user = useAuth((s) => s.user);
  const [results, setResults] = useState<ResultRow[]>([]);

  useEffect(() => {
    api.get('/student/results').then((res) => setResults(res.data)).catch(() => setResults([]));
  }, []);

  return (
    <Layout>
      <div className="flex justify-between items-start flex-wrap gap-4 mb-9">
        <div>
          <h1 className="text-2xl sm:text-[26px] font-bold text-blueprint-deep">
            Hi {user?.fullName?.split(' ')[0] ?? 'there'} 👋
          </h1>
          <p className="text-sm text-gray-400 mt-1">Your learning dashboard</p>
        </div>
        <div className="flex items-center gap-3 bg-white rounded-full pl-2.5 pr-5 py-2 shadow-card">
          <div className="w-9 h-9 rounded-full bg-circuit-green text-white flex items-center justify-center font-semibold text-sm">
            {user?.fullName?.[0] ?? 'S'}
          </div>
          <div className="text-sm font-semibold">{user?.fullName}</div>
        </div>
      </div>

      <InstallHint />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 mb-9">
        <StatCard label="Overall Average" value="78.4%" note="↑ 4.2 pts this term" accent="blueprint" />
        <StatCard label="Points" value="1,240" note="Rank #3 in class" accent="orange" />
        <StatCard label="Attendance" value="96%" note="On track" accent="green" />
      </div>

      <div className="card">
        <div className="flex justify-between items-center mb-6">
          <h2 className="font-bold text-blueprint-deep text-[17px]">My Units</h2>
          <a href="/units" className="text-signal-orange text-sm font-semibold">View all →</a>
        </div>

        {results.length === 0 ? (
          <p className="text-sm text-gray-400">
            No results yet — check back once your trainers publish marks.
          </p>
        ) : (
          results.map((r, i) => (
            <UnitRow
              key={i}
              code={r.assessment.unit.unitCode}
              name={r.assessment.unit.unitName}
              trainer={r.assessment.title}
              score={r.score}
              grade={r.score >= 70 ? 'A' : r.score >= 60 ? 'B' : 'C'}
            />
          ))
        )}
      </div>
    </Layout>
  );
}
