import { create } from 'zustand';

interface AuthUser {
  id: string;
  fullName: string;
  role: 'student' | 'trainer' | 'hod' | 'registrar' | 'institution_admin' | 'super_admin';
  institutionId: string;
}

interface AuthState {
  user: AuthUser | null;
  token: string | null;
  login: (user: AuthUser, token: string) => void;
  logout: () => void;
}

export const useAuth = create<AuthState>((set) => ({
  user: JSON.parse(localStorage.getItem('tvet_user') || 'null'),
  token: localStorage.getItem('tvet_token'),
  login: (user, token) => {
    localStorage.setItem('tvet_user', JSON.stringify(user));
    localStorage.setItem('tvet_token', token);
    set({ user, token });
  },
  logout: () => {
    localStorage.removeItem('tvet_user');
    localStorage.removeItem('tvet_token');
    set({ user: null, token: null });
  },
}));
