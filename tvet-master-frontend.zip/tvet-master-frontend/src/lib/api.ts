import axios from 'axios';

// Points at the NestJS backend from the companion tvet-master-backend project.
const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:3000/api/v1',
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('tvet_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export default api;
