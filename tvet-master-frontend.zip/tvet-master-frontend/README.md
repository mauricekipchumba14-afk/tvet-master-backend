# TVET Master — Frontend

A React + Vite + Tailwind PWA that connects to the `tvet-master-backend` API. Installable on phones and desktops, responsive across all orientations.

## Design system

| Token | Hex | Use |
|---|---|---|
| Blueprint Blue | `#0F4C81` | Primary brand, links, borders |
| Blueprint Deep | `#0A3760` | Sidebar, headers, dark surfaces |
| Signal Orange | `#F5811F` | Primary actions, alerts, points |
| Circuit Green | `#1F9D55` | Passing grades, success states |
| Steel Black | `#14181C` | Body text |
| Mist (near-white) | `#F3F6FA` | Page background |

Typefaces: **IBM Plex Sans** (UI text) + **IBM Plex Mono** (unit codes, scores, data) — chosen to match the technical/workshop identity of TVET institutions (unit codes like `ENG/CU/ET/CR/01/6/A` render as stamped mono tags throughout the app).

Padding is intentionally generous (`p-8`–`p-14` on cards and main content) per your spec, scaling down gracefully on small screens so nothing ever feels cramped on a phone either.

## Installable (PWA)

- `vite-plugin-pwa` auto-generates a service worker that caches the app shell, so it loads instantly on repeat visits and works offline for anything already cached.
- `InstallHint.tsx` listens for the browser's native `beforeinstallprompt` event and shows your own "Install" button instead of relying on the browser's hidden menu option — this is what makes the app "installable" from a phone or desktop browser onto the home screen / app list.
- **Before shipping**: replace `public/icon.svg` with real `icon-192.png` and `icon-512.png` (referenced in `vite.config.ts`'s manifest) — app stores and some Android launchers require actual PNGs, not just SVG.

## Responsive & rotation-friendly

- No fixed pixel widths or orientation locks anywhere — layouts use Tailwind's responsive grid/flex utilities, so rotating a phone from portrait to landscape simply reflows the existing CSS rather than requiring separate layouts.
- Sidebar navigation (desktop/tablet) becomes a bottom tab bar below the `md` breakpoint (768px) — this is the layout that also serves landscape phones well, since a bottom bar stays out of the way of the (now-wider) content area.
- `viewport-fit=cover` in `index.html` respects notches/safe areas on modern phones in either orientation.

## Running it

```bash
cp .env.example .env
# point VITE_API_URL at your running tvet-master-backend

npm install
npm run dev
```

Visit `http://localhost:5173`. For a production build (required to actually test PWA installability — the dev server doesn't register the service worker):

```bash
npm run build
npm run preview
```

## What's implemented

- Login (calls `/auth/login` on the backend, stores JWT)
- Role-aware routing: students land on `StudentDashboard`, trainers on `TrainerDashboard`, admins/registrars/HODs on `AdminDashboard`
- Student dashboard pulls real results from `/student/results`
- Responsive `Layout` shell (sidebar ↔ bottom tab bar) shared across all dashboards
- Reusable `StatCard`, `UnitRow` components matching the design system
- PWA install flow

## Next steps (not yet built)

- Full pages for Units, Timetable, Library, AI Tutor chat UI, Leaderboard (nav links exist; routes/pages don't yet)
- Trainer mark-entry and quiz-builder forms
- Admin CRUD screens for departments/courses/units/classes
- Real app icon PNGs
