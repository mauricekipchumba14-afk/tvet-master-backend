/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        blueprint: {
          DEFAULT: '#0F4C81',
          deep: '#0A3760',
        },
        signal: {
          orange: '#F5811F',
        },
        circuit: {
          green: '#1F9D55',
        },
        steel: {
          black: '#14181C',
        },
        mist: '#F3F6FA',
      },
      fontFamily: {
        sans: ['"IBM Plex Sans"', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'monospace'],
      },
      spacing: {
        18: '4.5rem',
      },
      boxShadow: {
        card: '0 2px 12px rgba(10,55,96,0.06)',
        lift: '0 24px 60px rgba(10,55,96,0.35)',
      },
      borderRadius: {
        xl2: '1rem',
      },
    },
  },
  plugins: [],
}
